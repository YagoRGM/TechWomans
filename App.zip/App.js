import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, ScrollView, } from 'react-native';


export default function App() {
    return (
      <ScrollView style={styles.container}>
          <Text style={styles.titulo}>Bem-vindo ao Tech Womans</Text>
          <Text style={styles.texto}>O Futuro da TI é feminino</Text>
      </ScrollView>
            
  );
}


const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    padding: 20,
  },
  titulo: { 
    fontSize: 30, 
    marginVertical: 20,
    color: 'black',
  },
  texto: {
    fontSize: 18,
    color: 'gray',
  },

});
